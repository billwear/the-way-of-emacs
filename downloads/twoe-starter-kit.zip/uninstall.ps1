$ErrorActionPreference = "Stop"
$KitRoot = if ($env:KIT_ROOT) { $env:KIT_ROOT } else { Join-Path $env:USERPROFILE ".twoe" }
$ans = Read-Host "This will remove $KitRoot (starter kit only). Proceed? [y/N]"
if ($ans -match '^(y|Y)$') { Remove-Item -Recurse -Force $KitRoot; Write-Host "Removed $KitRoot" } else { Write-Host "Cancelled." }
