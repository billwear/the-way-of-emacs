#!/usr/bin/env bash
set -euo pipefail

KIT_ROOT="${KIT_ROOT:-$HOME/.twoe}"
KIT_DIR="$KIT_ROOT/kit"

mkdir -p "$KIT_DIR"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# sync kit to user dir
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete "$SCRIPT_DIR/kit/" "$KIT_DIR/"
else
  rm -rf "$KIT_DIR"
  mkdir -p "$KIT_DIR"
  cp -R "$SCRIPT_DIR/kit/." "$KIT_DIR/"
fi

exec emacs -Q \
  --eval "(setq user-emacs-directory (expand-file-name \"$KIT_DIR/\"))" \
  --load "$KIT_DIR/init.el"
