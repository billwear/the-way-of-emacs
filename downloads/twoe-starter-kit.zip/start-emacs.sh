#!/usr/bin/env bash
set -euo pipefail

KIT_ROOT="${KIT_ROOT:-$HOME/.twoe}"
KIT_DIR="$KIT_ROOT/kit"
PORTABLE_DIR="$KIT_ROOT/emacs-portable"

mkdir -p "$KIT_DIR" "$PORTABLE_DIR"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# sync kit to user dir
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete "$SCRIPT_DIR/kit/" "$KIT_DIR/"
else
  rm -rf "$KIT_DIR"
  mkdir -p "$KIT_DIR"
  cp -R "$SCRIPT_DIR/kit/." "$KIT_DIR/"
fi

launch_with_binary() {
  local bin="$1"
  exec "$bin" -Q \
    --eval "(setq user-emacs-directory (expand-file-name \"$KIT_DIR/\"))" \
    --load "$KIT_DIR/init.el"
}

have_emacs() { command -v emacs >/dev/null 2>&1; }

OS="$(uname -s)"
case "$OS" in
  Linux)
    if have_emacs; then
      launch_with_binary "$(command -v emacs)"
    else
      echo "Emacs not found. Install with your package manager, then re-run:"
      echo "  Ubuntu/Debian: sudo apt install emacs"
      echo "  Fedora/RHEL:   sudo dnf install emacs"
      echo "  Arch:          sudo pacman -S emacs"
      exit 1
    fi
    ;;
  Darwin)
    if have_emacs; then
      launch_with_binary "$(command -v emacs)"
    else
      echo "Emacs not found. Attempting macOS DMG launch..."
      TMPDMG="$KIT_ROOT/Emacs.dmg"
      URL="https://emacsformacosx.com/emacs-builds/Emacs-29.4-universal.dmg"
      echo "Downloading $URL ..."
      if ! curl -L --fail -o "$TMPDMG" "$URL"; then
        echo "Download failed. If you have Homebrew, try: brew install --cask emacs"
        exit 1
      fi
      MOUNT_OUT=$(hdiutil attach "$TMPDMG" -nobrowse -quiet) || { echo "Mount failed"; exit 1; }
      VOLUME=$(echo "$MOUNT_OUT" | sed -n 's/^.*\(\/Volumes\/Emacs.*\)$/\1/p' | head -n1)
      if [ -z "$VOLUME" ]; then
        echo "Could not mount DMG. Try: brew install --cask emacs"; exit 1
      fi
      mkdir -p "$PORTABLE_DIR"
      cp -R "$VOLUME/Emacs.app" "$PORTABLE_DIR/"
      hdiutil detach "$VOLUME" -quiet || true
      APPBIN="$PORTABLE_DIR/Emacs.app/Contents/MacOS/Emacs"
      if [ ! -x "$APPBIN" ]; then
        echo "Emacs binary not found in app bundle. Try: brew install --cask emacs"
        exit 1
      fi
      launch_with_binary "$APPBIN"
    fi
    ;;
  MINGW*|MSYS*|CYGWIN*)
    echo "You're on Windows in a POSIX shell. Use PowerShell: start-emacs.ps1"
    exit 1
    ;;
  *)
    echo "Unsupported OS: $OS"; exit 1
    ;;
esac
