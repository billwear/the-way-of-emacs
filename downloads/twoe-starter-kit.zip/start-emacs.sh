#!/usr/bin/env bash
set -euo pipefail

KIT_ROOT="${KIT_ROOT:-$HOME/.twoe}"
KIT_DIR="$KIT_ROOT/kit"
PORTABLE_DIR="$KIT_ROOT/emacs-portable"

mkdir -p "$KIT_DIR" "$PORTABLE_DIR"

# Ensure kit files exist relative to this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# Sync kit content if running from unpacked zip
rsync -a --delete "$SCRIPT_DIR/kit/" "$KIT_DIR/" 2>/dev/null || cp -r "$SCRIPT_DIR/kit/." "$KIT_DIR/"

launch_with() {
  local em="$1"
  echo "Launching: $em -Q --init-directory \"$KIT_DIR\""
  exec "$em" -Q --init-directory "$KIT_DIR"
}

have_emacs() {
  command -v emacs >/dev/null 2>&1
}

OS="$(uname -s)"
case "$OS" in
  Linux)
    if have_emacs; then
      launch_with "$(command -v emacs)"
    else
      echo "Emacs not found. On Linux the simplest route is your package manager."
      echo "Ubuntu/Debian:   sudo apt install emacs"
      echo "Fedora/RHEL:     sudo dnf install emacs"
      echo "Arch:            sudo pacman -S emacs"
      echo ""
      echo "After installing, re-run: $0"
      exit 1
    fi
    ;;
  Darwin)
    if have_emacs; then
      launch_with "$(command -v emacs)"
    else
      echo "Emacs not found. Attempting a temporary macOS setup..."
      TMPDMG="$KIT_ROOT/Emacs.dmg"
      # Try Emacs for macOS DMG (fallback to Homebrew if download fails)
      set +e
      URL="https://emacsformacosx.com/emacs-builds/Emacs-29.4-universal.dmg"
      echo "Downloading $URL ..."
      curl -L --fail -o "$TMPDMG" "$URL"
      if [ $? -ne 0 ]; then
        echo "Download failed. If you have Homebrew, try:"
        echo "  brew install --cask emacs"
        exit 1
      fi
      set -e
      echo "Mounting DMG..."
      MOUNT_OUT=$(hdiutil attach "$TMPDMG" -nobrowse -quiet)
      VOLUME=$(echo "$MOUNT_OUT" | sed -n 's/^.*\(\/Volumes\/Emacs.*\)$/\1/p' | head -n1)
      if [ -z "$VOLUME" ]; then
        echo "Could not mount DMG. Try Homebrew: brew install --cask emacs"
        exit 1
      fi
      echo "Copying Emacs.app to $PORTABLE_DIR ..."
      cp -R "$VOLUME/Emacs.app" "$PORTABLE_DIR/"
      hdiutil detach "$VOLUME" -quiet || true
      open -a "$PORTABLE_DIR/Emacs.app" --args -Q --init-directory "$KIT_DIR"
    fi
    ;;
  MINGW*|MSYS*|CYGWIN*)
    echo "You're on Windows in a POSIX shell. Please run start-emacs.ps1 in PowerShell for a portable setup."
    exit 1
    ;;
  *)
    echo "Unsupported OS: $OS"
    exit 1
    ;;
esac
