# The Way of Emacs — Starter Kit (Portable-ish)

This starter kit lets you try Emacs **without touching your existing config**.

- If Emacs is already installed, we run it **vanilla** with a tiny, isolated init.
- If Emacs is missing:
  - **Windows:** we download the official GNU Windows zip into your home and run it **portable** (no admin).
  - **macOS:** we try to mount a DMG (best effort). If that fails, we offer a Homebrew one‑liner.
  - **Linux:** there is no official portable binary; we print the package‑manager command. If Emacs is installed, we just use it.

Everything lives under your home (default `~/.twoe`), so removal is just deleting that folder (or run `uninstall` scripts).

## Quick start
**Linux/macOS (bash/zsh):**
```sh
./start-emacs.sh
```

**Windows (PowerShell):**
```powershell
./start-emacs.ps1
```

## What gets created
- Config (isolated): `~/.twoe/kit/` (this folder contains `init.el` and tour files).
- **Windows only (if we download Emacs):** `~/.twoe/emacs-portable/`

Your normal `~/.emacs.d` or `%APPDATA%` is **not used**.

## Uninstall
- Linux/macOS:
  ```sh
  ./uninstall.sh
  ```
- Windows (PowerShell):
  ```powershell
  ./uninstall.ps1
  ```

