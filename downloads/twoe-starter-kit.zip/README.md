# The Way of Emacs — Starter Kit (v2.1)
Always-fallback launcher (no reliance on --init-directory).

- Runs Emacs with: -Q + --eval '(setq user-emacs-directory ...)' + --load init.el
- Keeps your normal Emacs config untouched.
- Windows downloads official GNU portable ZIP if Emacs missing.
- macOS tries Emacs.app DMG; runs the app's binary directly with fallback flags.
- Linux prints package-manager command if Emacs is missing.

Uninstall: use the provided uninstall script to remove ~/.twoe (or %USERPROFILE%\.twoe).
