#!/usr/bin/env bash
set -euo pipefail
KIT_ROOT="${KIT_ROOT:-$HOME/.twoe}"
read -rp "This will remove $KIT_ROOT (starter kit & any portable Emacs there). Proceed? [y/N] " ans
case "${ans:-N}" in
  y|Y) rm -rf "$KIT_ROOT"; echo "Removed $KIT_ROOT";;
  *)   echo "Cancelled." ;;
esac
