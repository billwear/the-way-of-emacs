# Starter Kit (Windows) – v2.4.2
$ErrorActionPreference = "Stop"
$KitRoot = if ($env:KIT_ROOT) { $env:KIT_ROOT } else { Join-Path $env:USERPROFILE ".twoe" }
$KitDir  = Join-Path $KitRoot "kit"
New-Item -Force -ItemType Directory -Path $KitDir | Out-Null

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
robocopy (Join-Path $ScriptDir "kit") $KitDir /MIR | Out-Null

$EmacsExe = (Get-Command emacs.exe -ErrorAction SilentlyContinue)?.Source
if (-not $EmacsExe) { $EmacsExe = (Get-Command runemacs.exe -ErrorAction SilentlyContinue)?.Source }

if (-not $EmacsExe) {
  Write-Host "Emacs not found on PATH."
  Write-Host "Install Emacs first (e.g., winget install GNU.Emacs, or https://ftp.gnu.org/gnu/emacs/windows/)."
  Read-Host "Press Enter to exit"
  exit 1
}

& $EmacsExe -Q `
  --eval "(setq user-emacs-directory (Expand-FileName `"$KitDir/`"))" `
  --load (Join-Path $KitDir "init.el")
