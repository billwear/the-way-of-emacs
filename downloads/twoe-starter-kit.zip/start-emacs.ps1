# Starter Kit (Windows) – always-fallback
$ErrorActionPreference = "Stop"
$KitRoot = if ($env:KIT_ROOT) { $env:KIT_ROOT } else { Join-Path $env:USERPROFILE ".twoe" }
$KitDir  = Join-Path $KitRoot "kit"
$PortDir = Join-Path $KitRoot "emacs-portable"
New-Item -Force -ItemType Directory -Path $KitDir, $PortDir | Out-Null

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
robocopy (Join-Path $ScriptDir "kit") $KitDir /MIR | Out-Null

function Launch-With($exe) {
  & $exe -Q `
    --eval "(setq user-emacs-directory (expand-file-name `"$KitDir/`"))" `
    --load (Join-Path $KitDir "init.el")
}

$EmacsExe = (Get-Command emacs.exe -ErrorAction SilentlyContinue)?.Source
if (-not $EmacsExe) { $EmacsExe = (Get-Command runemacs.exe -ErrorAction SilentlyContinue)?.Source }

if (-not $EmacsExe) {
  $WinZipUrl = "https://ftp.gnu.org/gnu/emacs/windows/emacs-29.4-x86_64.zip"
  $ZipPath   = Join-Path $PortDir "emacs.zip"
  Invoke-WebRequest -Uri $WinZipUrl -OutFile $ZipPath
  Expand-Archive -Path $ZipPath -DestinationPath $PortDir -Force
  $EmacsExe = (Get-ChildItem -Path $PortDir -Recurse -Filter runemacs.exe | Select-Object -First 1).FullName
  if (-not $EmacsExe) { $EmacsExe = (Get-ChildItem -Path $PortDir -Recurse -Filter emacs.exe | Select-Object -First 1).FullName }
}

Launch-With $EmacsExe
