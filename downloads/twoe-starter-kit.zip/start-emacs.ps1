# The Way of Emacs — Starter Kit (Windows portable)
$ErrorActionPreference = "Stop"

$KitRoot = if ($env:KIT_ROOT) { $env:KIT_ROOT } else { Join-Path $env:USERPROFILE ".twoe" }
$KitDir  = Join-Path $KitRoot "kit"
$PortDir = Join-Path $KitRoot "emacs-portable"
New-Item -Force -ItemType Directory -Path $KitDir, $PortDir | Out-Null

# Sync kit folder next to this script into $KitDir
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
robocopy (Join-Path $ScriptDir "kit") $KitDir /MIR | Out-Null

function Launch-With($exe) {
  Write-Host "Launching: $exe -Q --init-directory $KitDir"
  & $exe -Q --init-directory $KitDir
}

# If Emacs already in PATH, just use it
$EmacsExe = (Get-Command emacs.exe -ErrorAction SilentlyContinue)?.Source
if (-not $EmacsExe) { $EmacsExe = (Get-Command runemacs.exe -ErrorAction SilentlyContinue)?.Source }

if ($EmacsExe) {
  Launch-With $EmacsExe
  exit 0
}

# Portable download from official GNU Windows builds
$WinZipUrl = "https://ftp.gnu.org/gnu/emacs/windows/emacs-29.4-x86_64.zip"
$ZipPath   = Join-Path $PortDir "emacs.zip"
$DestDir   = Join-Path $PortDir "emacs-29.4"

Write-Host "Emacs not found in PATH."
Write-Host "Downloading portable Windows build..."
Invoke-WebRequest -Uri $WinZipUrl -OutFile $ZipPath

Write-Host "Extracting..."
Expand-Archive -Path $ZipPath -DestinationPath $PortDir -Force

# Try common run paths
$RunExe = Get-ChildItem -Path $PortDir -Recurse -Filter runemacs.exe -ErrorAction SilentlyContinue | Select-Object -First 1
if (-not $RunExe) { $RunExe = Get-ChildItem -Path $PortDir -Recurse -Filter emacs.exe | Select-Object -First 1 }

if (-not $RunExe) {
  Write-Error "Could not locate Emacs executable in $PortDir"
}

Launch-With $RunExe.FullName
